package du.dept.dao;

import java.util.List;

import du.dept.domain.DeptVO;

public interface DeptDAO {

	public List<DeptVO> selectDeptList();
}
